function Match(){

			var a = document.getElementById("pw").value;
			
			if(a==true)
			{
				alert("Matched");
			}
			else
			{
				alert("Mismatched");
				return false;
			}
			
}

function check(){

			if(document.getElementById("cbox").checked)
			{
				document.getElementById("button3").disabled = false;
			}
			
			else
			{
				document.getElementById("button3").disabled = true;
			}
}

function loadData(data){
	if (data == "b1"){
		alert("Computer Programming");
		document.getElementById("sec1").background="LOGO/options/cp.jpg";
	}
	else if(data == "b2"){
		alert("Mathematics");
		document.getElementById("sec1").background="LOGO/options/math.jpg";
	}
		else if(data == "b3"){
		alert("Biolagy");
		document.getElementById("sec1").background="LOGO/options/bio.jpg";
	}
		else if(data == "b4"){
		alert("Physics");
		document.getElementById("sec1").background="LOGO/options/phy.jpg";
	}
		else if(data == "b5"){
		alert("Chemistry");
		document.getElementById("sec1").background="LOGO/options/chem.jpg";
	}
		else if(data == "b6"){
		alert("Economics");
		document.getElementById("sec1").background ="LOGO/options/eco.jpg";
	}
		else if(data == "b7"){
		alert("Languages");	
		document.getElementById("sec1").background="LOGO/options/lan.jpg";
	}
		else if(data == "b8"){
		alert("History");
		document.getElementById("sec1").background ="LOGO/options/his.jpg";
	}
		else if(data == "b9"){
		alert("Geography");
		document.getElementById("sec1").background ="LOGO/options/geo.jpg";
	}
		else if(data == "b10"){
		alert("Citizenship");
		document.getElementById("sec1").background ="LOGO/options/citi.jpg";
	}
		else if(data == "b11"){
		alert("Aestheticg");
		document.getElementById("sec1").background  ="LOGO/options/aes.jpg";
	}

}	 
function okPress(){
	alert("Press OK if you need send a reply");
}


