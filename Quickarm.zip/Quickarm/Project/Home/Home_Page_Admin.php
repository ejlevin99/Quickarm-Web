
<!DOCTYPE html>
<?php
	include_once 'config.php';
?>

<?php
session_start();
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$_SESSION['Login']=$_POST['email'];
	$_SESSION['Password']=$_POST['pw'];
	header("Location:loginvalidateadmin.php");
}
?>
<html>
<head>
	<link rel = "stylesheet" type = "text/css" href = "Home_page_css.css">
	<script src="Home_page_js.js"></script>

</head>

<body background = "../../LOGO/map.gif">

<div class="h">
<header class="header1">

	<center>
		<h2 class ="logo1">Online Discussion Forum</h2>
	</center>

</header>

<header class ="header2">

	<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>

	<center>
		<img src = "../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img2" ></img>
	</center>

</header>

<nav class="menu">
	<ul>
		<li><a href="#">Home</a></li>
		<li><a href="../Answer2/About_Answer.html">Answers</a></li>
		<li><a href="../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../contact us/contact us.html">Contact us</a></li>
		
	</ul>
	
	
		<button class="button button1">
			<a href="../Logg/Profile_Page_Admin.php"><img src="../../LOGO/person1.png" width="35px" height="25px"></a>
		</button>
		<a href="../Add Question/About_Question_.html"><button class="button button2">Add Questions</button></a>	

</nav>
</div>

<div class="p1">
	<p>Welcome!</p>
</div>

<div class="table1">
<fieldset class="textbox1">Select your Category</fieldset>

<fieldset Class="textbox2" >	
	<li><a class="L1" onclick="Subjectfunction('L1')" href="#">Computer Programming</a></li>
	<li><a class="L2" onclick="Subjectfunction('L2')" href="#">Mathematics</a></li>
	<li><a class="L3" onclick="Subjectfunction('L3')" href="#">Biology</a></li>
	<li><a class="L4" onclick="Subjectfunction('L4')" href="#">Physics</a></li>
	<li><a class="L5" onclick="Subjectfunction('L5')" href="#">Chemistry</a></li>
	<li><a class="L6" onclick="Subjectfunction('L6')" href="#">Economics</a></li>
	<li><a class="L7" onclick="Subjectfunction('L7')" href="#">Languages</a></li>
	<li><a class="L8" onclick="Subjectfunction('L8')" href="#">History</a></li>
	<li><a class="L9" onclick="Subjectfunction('L9')" href="#">Geography</a></li>
	<li><a class="L10" onclick="Subjectfunction('L10')" href="#">Citizenship</a></li>
	<li><a class="L11" onclick="Subjectfunction('L11')" href="#">Aesthetic</a></li>
</fieldset>	
</div>

<div class="div1">
<p class="textbox3">Now it is easy to get answer for the questions that you make trouble, Stop visiting every where in google and become a member of our. 
Go through our Sing Up page and become a registered user in our site. Hence, in order to add and answer for the qustions, you must be a registered user in our website 
We are providing accurate answers for your questions under the supervise of professional editors, So Hurry up, Go through our Sign Up page and Explore your wisdom in smart way!
 Hey let's Start.</p>
</div>


<div class="div2"><center style="font-size:30px">Sign In</center>
<form action="" method="POST" ><br />
<div class="div3">
<div class="div4" style="font-size:30px">E-mail</div><br/>
<div class="div4"><input type="email" name="email" placeholder=" e-mail" class="tx" id="em" ></div><br/>
<div class="div4" style="font-size:30px">Password</div><br/>
<div class="div4"><input type="Password" name="pw" placeholder=" password" class="tx" id="pw" ></div><br/><br/>
<div class="div4"><input type="submit" name="sub" class="button3"  id="button3" value="Sign in" disabled></div>
<div class="div4"><input type="checkbox" name="cbox" class="cbox" id="cbox" onclick="check()">Stay signed in</div>
<div class="div4"><p class="p2"><a href="../Forgot Password/Forgot Password.php" style="text-decoration:none;color:black">Trouble signing in?</a></p></div><br/>
<div class="div4"><button class="button4" name="reg" ><a href="../Registation Page/Registation Page.html" style="text-decoration:none;color:white" >Creat an account</a></button></div>
</div>
</form>
</div>

<div class="ad">
	<div class="txtad">
			<div class="imgcollection">
				<img src="../../LOGO/slide-img-1.png" style="height:auto; width:auto; margin-left:-35px" >
			</div>
			<div class="imgcollection">
				<img src="../../LOGO/slide-img-2.png" style="height:auto; width:auto;">
			</div>
	</div>
</div>


<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="../About Us/feedaback.html"><input type="button" class="button5" value="Feed Back"></a>
<div class="f1"><img src="../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>
<div class="f2"><a href="https://www.facebook.com"><img src="../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px "></a>
				<a href="https://twitter.com/login?lang=en"><img src="../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px"></a>
				<a href= "https://lk.linkedin.com"><img src="../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px"></a>
				<a href="https://www.instagram.com"><img src="../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px"></a>
</div>				
</footer>
</div>

</body>
</html>