<?php

include_once "config.php";

session_start();

$user=$_SESSION['Login'];
$pw=$_SESSION['Password'];


$sql="SELECT e_mail from user where e_mail='$user'";
$result=mysqli_query($conn,$sql);
if ($result -> num_rows > 0)
{
	while ($row=$result -> fetch_assoc())
	{
		$sql="SELECT password from user where password='$pw'";
		$result=mysqli_query($conn,$sql);
		if ($result -> num_rows > 0)
		{
			while ($row=$result -> fetch_assoc())
			{
				echo "<script> alert('Login details validated') </script>";	
				header("Location:../Logg/Profile_Page.php");
			}
		}
		
		else
		{
			echo "<script> alert('password is wrong') </script>";
			header("Location:Home_Page.php");
			
		}
		
	}
}
else
{	
	session_destroy();
	header("Location:Home_Page.php");
}

?>
