function Match(){

			var a = document.getElementById("em").value;
			var b = document.getElementById("pw").value;

			
			if(a=="editor@quickarm.com" && b=="editor")
			{
				alert("Matched");
			}
			else
			{
				alert("Mismatched");
				return false;
			}
			
}

function check(){

			if(document.getElementById("cbox").checked)
			{
				document.getElementById("button3").disabled = false;
			}
			
			else
			{
				document.getElementById("button3").disabled = true;
			}
}

function Subjectfunction(x){
			
			if(x=="L1")
			{
				alert("If you want to go Computer Programming, You have to sign in ");
			}	
				
				else if(x=="L2")
					{
						alert("If you want to go Mathematics, You have to sign in ");
					}	
					
					else if(x=="L3")
					{
						alert("If you want to go Biolagy, You have to sign in Biolagy");
					}	
					
						else if(x=="L4")
					{
						alert("If you want to go Physics, You have to sign in ");
					}

					
						else if(x=="L5")
					{
						alert("If you want to go Chemistry, You have to sign in ");
					}
					
					
						else if(x=="L6")
					{
						alert("Economics");
					}
					
					
						else if(x=="L7")
					{
						alert("Languages");
					}
					
						else if(x=="L8")
					{
						alert("History");
					}
					
						else if(x=="L9")
					{
						alert("Geography");
					}
					
						else if(x=="L10")
					{
						alert("Citizenship");
					}
					
						else if(x=="L11")
					{
						alert("Aesthetic");
					}
					
					
					
					
					
						
					
			
}