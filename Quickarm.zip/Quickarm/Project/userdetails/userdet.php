<?php
	include_once 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<link rel = "stylesheet" type = "text/css" href = "Admin_page_1_css.css">
	<script src="Admin_page_1_js.js"></script>

</head>

<body background = "../../LOGO/map.gif">

<div class="h">
<header class="header1">

	<center>
		<h2 class ="logo1">Online Discussion Forum</h2>
	</center>

</header>

<header class ="header2">

	<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>

	<center>
		<img src = "../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img2" ></img>
	</center>

</header>

<nav class="menu">
	<ul>
		<li><a href="../Home/Home_Page.html">Home</a></li>
		<li><a href="../Answer2/About_Answer.html">Answers</a></li>
		<li><a href="../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../contact us/contact us.html">Contact us</a></li>
		
	</ul>
	
	
	<form class="search-form">	
		<input style="border-radius:8px 0px 0px 8px" type ="text" placeholder ="search" >
		<button class="button">Search</button>
	</form>	
		<button class="button button1">
			<a href="../Logg/Profile_Page.html"><img src="../../LOGO/person1.png" width="35px" height="25px"></a>
		</button>
		<a href="../Answer/Answer_final.html"><button class="button button2">Add Questions</button></a>	

</nav>
</div>


<div class="div8">
		<table border ="1" width = "100%">
		<tr>
			<th>User Id</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>E mail</th>
			<th>Birth of date</th>
			<th>Delete</th>
		</tr>
	<?php
	
	$sql="select * from user";
	
	$result= $conn->query($sql);
	
	if ($result->num_rows> 0 )
	{
		//output data of each row
		while($row = $result->fetch_assoc()){
			$id=$row['user_id'];
			echo"<tr><td>".$row["user_id"]."</td>";
			echo"<td>".$row["f_name"]."</td>";
			echo"<td>".$row["l_name"]."</td>";
			echo"<td>".$row["e_mail"]."</td>";
			echo"<td>".$row["b_day"]."</td>";
			
			
			echo"<td><button type ='submit'><a href ='delete.php?Id=$id'> Delete</a></button></td></tr>";	
		}	
	}
	else{
		//echo "0 results";
	}
	echo "</table>";
	$conn->close();
	?>

</div>



<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="../About Us/feedaback.html"><input type="button" class="button5" value="Feed Back"></a>
<div class="f1"><img src="../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>

	<div class="f2">
		<a href="https://www.facebook.com"><img src="../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px "></a>
		<a href="https://twitter.com/login?lang=en"><img src="../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px"></a>
		<a href= "https://lk.linkedin.com"><img src="../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px"></a>
		<a href="https://www.instagram.com"><img src="../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px"></a>
	</div>				
</footer>
</div>

</body>
</html>