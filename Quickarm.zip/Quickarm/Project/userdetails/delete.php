<?php
	include_once 'config.php';
	$recordId=$_GET['Id'];
	
	//Attempt delete query execution
	$sql="DELETE FROM user WHERE user_id='$recordId' ";
	
	if(mysqli_query($conn,$sql)){
		//echo "<script> alert('Deleted Item you selected')</script>";
		header("Location:userdet.php");
}
	else{
		echo "<script> alert('There is an error')</script>";
	}
	mysqli_close($conn);
	
?> 		