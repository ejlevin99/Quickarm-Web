<!DOCTYPEhtml>
<html>
	<head>
	
	<?php
				include_once 'config_feed.php';
			?>
		<title>Add Questions</title>
		<link rel="stylesheet" type="text/css" href="styles/style.css">
		<style>
			h1 {
				font-size:30px;
				}
		</style>
		
		<script src="js/javas.js"></script>
	</head>
	
	<body background= "../../LOGO/options.cp.jpg" id ="sec1">

	<header>

		<div class = "header1">

			<center>
				<h2 class ="logo1">Online Discussion Forum</h2>
			</center>
		</div>

	</header>

	<header class ="header2">

		<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>

	<center>
		<img src = "../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img2" ></img>
	</center>

	</header>

	<nav class="meu">
		<ul>
		
		<li><a href="../Home/Home_Page.html">Home</a></li>
		<li><a href="../Answer2/About_Answer.html">Answers</a></li>
		<li><a href="../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../contact us/contact us.html">Contact us</a></li>
			
		</ul>
	
	
	<form class="search-form" action="search_question.php" method="POST">
		
		<input type ="text" placeholder ="Search by a question" name="query1">
		
		<input type="submit" class="button" value="Search" name="submit1"></input>
	
	</form>	
			<button class="button button1">
				<a href="../Logg/Profile_Page.html"><img src="../../LOGO/person1.png" width="35px" height="25px"></a>
			</button>
			<a href="#"><button class="button button2" href="#" style="text-decoration:none;color:black">Add Questions</button></a>	
	

	</nav>

	
		
		<?php
				
				
				if(isset($_POST['submit1']))
				{
							$id = $_POST['query1'];
					
					
							$query = "select * from  qcom where question ='$id'";
							$query_run = mysqli_query($conn,$query);
							
					
					
					echo "<h2>The related question for your search <b> ".$id."</b></h2>" ;
					
					while($row = mysqli_fetch_array($query_run))
					{
						?>
						
						
						
						<form action="" method="POST">
						
							<fieldset>
							<legend>Question Details</legend>
							Question ID  : <input type="text" name="id" value="<?php echo $row['q_id']?>"/> <br><br>
							Question : <input type="text" name="fname" value="<?php echo $row['question']?>"/> <br><br>
							
							</fieldset>
							
						</form>
						
								<br><br><br>
						<?php
						
								
					}
					
					
					
					
					
					
				}
				
				else
				{
					echo "Server Not Found";
				}
				
				?>
				
		
		
<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="../About Us/feedaback.html"><input type="button" class="button5" value="Feed Back"></a>
<div class="f1"><img src="../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>
<div class="f2"><a href="https://www.facebook.com"><img src="../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px "></a>
				<a href="https://twitter.com/login?lang=en"><img src="../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px"></a>
				<a href= "https://lk.linkedin.com"><img src="../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px"></a>
				<a href="https://www.instagram.com"><img src="../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px"></a>
</div>				
</footer>
</div>
	</body>
</html>