function successmsg1()
{
	confirm("You are a registed user.");
}

function successmsg2()
{
	confirm("Please log into our system.");
}



