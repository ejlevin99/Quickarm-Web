<?php
include_once 'confi.php';
?>
<!doctype html>
<html>
<head>
<style>
body{
	background-image:url("../../LOGO/map.gif");
}
.style1{
	font-size:16px;
	color:black;
	background:rgba(20,20,20,.2);
	border-radius:5px;
	padding-top:40px;
	padding-bottom:40px;
	width:40%;
	position:relative;
	left:410px;
	top:75px;
	margin-left:150px;

}
hr{
	border:2px solid black;
}
.subbtn{
	width:150px;
	border-radius:5px;
	font-size:16px;
}
.textbx{
	width:260px;
	height:30px;
	font-size:14px;
	padding-top:5px;
	padding-bottom:5px;
	border-radius:5px;

}
.x{
	margin-left:-150px;
	margin-top:20px;
}


</style>
</head>
<body>
<script>
	alert("Change your password here ..");
	
</script>
<header class = "header2">
<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>
<center>
<img src = "../../LOGO/quickarm.jpg" class="x" width ="288" height = "127" alt = "This is a sliit iamge">
</center>
</header>

<hr>
<div class="style1">
<center>
		<h1>Forgot Your Password ? </h1>
			<p>Don't worry. Reseting your password is easy.<br><br>Just tell us the email address you registered with<b> Quickarm.</b></p>
			<br>
			<form action ="forgot.php" method = "POST">
			<input class="textbx" type="email" name="em" placeholder=" Email address "pattern="[a-z0-9%+-_]+@[a-z]+\.[a-z]{2,3}" required><br><br>
			<input type="textarea" placeholder="Type your message here..." name="txt" style="width:250px; height:60px; border-radius:5px; font-size:14px; padding-left:10px;" required><br><br>
			<input class="subbtn" type="Submit" value="Submit" >
			</form>
</center>
</div>

</body>
</html>