<?php

	include_once 'confi.php';


	$email = $_POST["em"];
	$message = $_POST["txt"];

	
	$sql = "insert into forgotpassword(ID,Email,Message)values('','$email','$message')";

	if (mysqli_query($conn,$sql))
	{
		echo"Request send successfully!,Added your data to the database!";
		header("Location:../Home/Home_Page.php");
	}
	else
	{
		echo"User Details could not be added to the database!" ;

		
	} 
	
	//Close connection
	mysqli_close($conn);

?>