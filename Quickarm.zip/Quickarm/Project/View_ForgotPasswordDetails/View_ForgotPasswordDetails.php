<?php
	include_once 'Confi.php';
?>
		

<!DOCTYPE html>
<html>

	<head>
		<title>User Table for Admin</title>

		<link rel="stylesheet" type="text/css" href="style2.css">
		
		
		<style>
		
		h1{
			font-size:30px;
			}
			</style>


	<script src="feedback1.js">
	</script>
		
			
	</head>
	
	<body>
	
	<header>


		<div class = "header1">


		<center>
		
			<h2 class ="logo1">Online Discution Forum</h2>
 
		</center>

		</div>	
</header>



	<header class ="header2">


	<div class="logo2">		
	<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>
	</div>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<div class="topic">		
	<img src = "../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img10" ></img>
	
	</div>

	</header>



	<nav class="menu">


	<ul>
		<li><a href="../Home/Home_page.html">Home</a></li>
		<li><a href="../Answer/Answer_final.html">Answers</a></li>
		<li><a href="../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../contact us/contact us.html">Contact us</a></li>

	</ul>
	
	
	

	<form class="search-form" action="f_search.php" method="POST">
		
		<input type ="text" placeholder ="search" name="query1">
		
		<input type="submit" name="submit1"class="button" value="Search"></input>
	
	</form>	
	
	<button class="button button1">
			
	
	<a href="../Logg/Profile_Page.html"><img src="../../LOGO/person1.png" width="35px" height="25px"></a>
			</button>
		

	<a href="../Add Question/About_Question_.html"><button class="button button2">Add Questions</button></a>	
	

	

</nav>
	
	
	<br><br>
	
		
		
			
	<table border="1" width="100%">
	<tr>
	<th>User_ID</th>
	<th>Email</th>
	<th>Message</th>
	</tr>
	
	<?php
		$sql = "select * from forgotpassword";
		$result = $conn->query($sql);
		
		if($result->num_rows > 0)
		{
			//output the data of each row
			while($row = $result->fetch_assoc())
			{
				$id = $row["ID"];
				
				echo"<tr><td>".$row["ID"]."</td>";
				echo"<td>".$row["Email"]."</td>";
				echo"<td>".$row["Message"]."</td>";
				echo"<td><center><a href='delete_q.php?ID=$id'><input type='submit' id='btn' value='Delete' onclick='changecolor()'></center></td></tr>";	
			
			}
		}
		else
		{
			echo "0 results";
		}
		
		echo "</table>";
		
		$conn->close();
		
	
	
	?>
	
	
		

	

	


<br> <br>






</div>
	
<div id="displayThanks"></div>

<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="feedaback.html"><input type="button" class="button10" value="Feed Back"></a>
<div class="f1"><img src="../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>
<div class="f2"><a href="https://www.facebook.com"><img src="../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px "></a>
				<a href="https://twitter.com/login?lang=en"><img src="../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px"></a>
				<a href= "https://lk.linkedin.com"><img src="../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px"></a>
				<a href="https://www.instagram.com"><img src="../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px"></a>
</div>				
</footer>
</div>


	

  
  
	
	</body>

</html>