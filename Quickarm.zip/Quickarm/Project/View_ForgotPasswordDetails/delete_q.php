<?php
	include_once 'Confi.php';
?>

<?php
	
	$recordId = $_GET['ID'];
	$sql = "DELETE  FROM forgotpassword where ID = $recordId";
	$result = $conn -> query($sql);
	
			
if(mysqli_query($conn,$sql)){
	
	header("Location:View_ForgotPasswordDetails.php");
	
}

else {

	echo "<script> alert( 'Submission Failed')</script>";

}

mysqli_close($conn); 

?>