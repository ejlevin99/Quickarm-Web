function Match(){

			var a = document.getElementById("pw").value;
			
			if(a==true)
			{
				alert("Matched");
			}
			else
			{
				alert("Mismatched");
				return false;
			}
			
}

function check(){

			if(document.getElementById("cbox").checked)
			{
				document.getElementById("button3").disabled = false;
			}
			
			else
			{
				document.getElementById("button3").disabled = true;
			}
}

function Subjectfunction(x){
			
			if(x=="L1")
			{
				confirm("Do you want to select Computer Programming ?");
			}	
				
				else if(x=="L2")
					{
						confirm("Do you want to select Mathamatics ?");
					}	
					
					else if(x=="L3")
					{
						confirm("Do you want to select Biology ?");
					}	
					
						else if(x=="L4")
					{
						confirm("Do you want to select Physics ?");
					}

					
						else if(x=="L5")
					{
						confirm("Do you want to select Chemistry ?");
					}
					
					
						else if(x=="L6")
					{
						confirm("Do you want to select Economics ?");
					}
					
					
						else if(x=="L7")
					{
						confirm("Do you want to select Languages ?");
					}
					
						else if(x=="L8")
					{
						confirm("Do you want to select History ?");
					}
					
						else if(x=="L9")
					{
						confirm("Do you want to select Geography ?");
					}
					
						else if(x=="L10")
					{
						confirm("Do you want to select Citizenship ?");
					}
					
						else if(x=="L11")
					{
						confirm("Do you want to select Aesthetic ?");
					}					
			
}

function edit1(){
					
				confirm("Do you want to edit ?");				
}

function edit2(){
					
				confirm("Do you want to delete ?");				
}

function edit3(){
					
				confirm("Do you want to submit ?");				
}

function loadData(x)
{
	if(x == "L1")
	{
		document.getElementById("cp12").innerHTML = "Computer Programming";
		document.getElementById("s").innerHTML = "Computer Programming";
		document.getElementById("r").innerHTML = "Computer Programming";
	}
	
	else if(x == "L2")
	{
		document.getElementById("cp12").innerHTML = "Mathematics";
		document.getElementById("s").innerHTML = "Mathematics";
		document.getElementById("r").innerHTML = "Mathematics";
		
	}

	else if(x == "L3")
	{
		document.getElementById("cp12").innerHTML = "Biology";
		document.getElementById("s").innerHTML = "Biology";
		document.getElementById("r").innerHTML = "Biology";
	}

	else if(x == "L4")
	{
		document.getElementById("cp12").innerHTML = "Physics";
		document.getElementById("s").innerHTML = "Physics";
		document.getElementById("r").innerHTML = "Physics";
	}

	else if(x == "L5")
	{
		document.getElementById("cp12").innerHTML = "Chemistry";
		document.getElementById("s").innerHTML = "Chemistry";
		document.getElementById("r").innerHTML = "Chemistry";
	}

	else if(x == "L6")
	{
		document.getElementById("cp12").innerHTML = "Economics";
		document.getElementById("s").innerHTML = "Chemistry";
		document.getElementById("r").innerHTML = "Chemistry";
	}

	else if(x == "L7")
	{
		document.getElementById("cp12").innerHTML = "Languages";
		document.getElementById("s").innerHTML = "Languages";
		document.getElementById("r").innerHTML = "Languages";
	}

	else if(x == "L8")
	{
		document.getElementById("cp12").innerHTML = "History";
		document.getElementById("s").innerHTML = "History";
		document.getElementById("r").innerHTML = "History";
	}

	else if(x == "L9")
	{
		document.getElementById("cp12").innerHTML = "Geography";
		document.getElementById("s").innerHTML = "Geography";
		document.getElementById("r").innerHTML = "Geography";
	}

	else if(x == "L10")
	{
		document.getElementById("cp12").innerHTML = "Citizenship";
		document.getElementById("s").innerHTML = "Citizenship";
		document.getElementById("r").innerHTML = "Citizenship";
	}

	else if(x == "L11")
	{
		document.getElementById("cp12").innerHTML = "Aesthetic";
		document.getElementById("s").innerHTML = "Aesthetic";
		document.getElementById("r").innerHTML = "Aesthetic";
	}	
}


function txtenable(){
		
		document.getElementById("r").disabled = false;	
}

function visibility(){
	
		 document.getElementById("v1").style.visibility = "visible";
		 document.getElementById("snd3").style.visibility = "visible";
}

function hide_(){
	
		 document.getElementById("v1").style.visibility = "hidden";
		 document.getElementById("snd3").style.visibility = "hidden";
}


		