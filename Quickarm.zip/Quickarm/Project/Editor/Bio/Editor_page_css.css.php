
li a{
	text-decoration: none;
	color:black;
}

li a:hover{
		color:blue;
		opacity:0.5;
		font-size:18px;	
}

.q{
		!width:972px;
		!height:160px;
		margin-top:10px;
		margin-left:5px;
		border:1px black groove;
		background:rgba(20,20,20,.1);
		position:absolute;
}

.v{

		margin-top:0px;
		margin-left:0px;
		border:1px black groove;
		background:rgba(20,20,20,.1);
		position:absolute;

}


.snd1{
	
		color:white;
		border-radius:0 0px 0px 0px;
		background-color:Black;
		width:50px;
		height:20px;
		}
.snd{
	
		color:white;
		border-radius:0 0px 0px 0px;
		background-color:Black;
		width:150px;
		height:50px;

}

.div1{
		position:absolute;
		background-color:;
		width:1000px;
		height:730px;
		margin-left:320px;
		margin-top:360px;
		padding:3px;
		border:1px black groove;
		
}

.div2{
		
		position:absolute;
		background-color:;
		width:997px;
		height:701px;
		margin-left:0px;
		margin-top:0px;
		
		
}

.div3{
		background-color:;
		width:997px;
		height:77px;
		position:absolute;
	
		
		
		
}

.div4{
		background-color:;
		width:400px;
		height:30px;
		position:absolute;
		margin-top:80px;
		margin-left:5px;
		border:1px black groove;
		padding:10px;
		
		
		
}

.div5{
		background-color:;
		width:997px;
		height:196px;
		position:absolute;
		margin-top:160px;
		
		
				
}

.div6{
		background-color:;
		width:997px;
		height:80px;
		position:absolute;
		margin-top:355px;
		
		
		
		
}

.div7{
		background-color:;
		width:997px;
		height:196px;
		position:absolute;
		margin-top:438px;
		
}

.div8{
		background-color:;
		width:450px;
		height:700px;
		position:absolute;
		margin-top:360px;
		margin-left:1423px;
		padding:3px;
		border:1px black groove;
}

.div9{
		width:448px;
		height:60px;
		background-color:;
		border:1px black groove;
}
.div10{
		
		width:445px;
		height:550px;
		background-color:;
		margin-top:17px;

		
}

.div11{
	
		margin-top:10px;
		font-size:15px;
		position:absolute;
		margin-left:290px;
	
}

.div12{
		margin-top:660px;
		font-size:15px;
		position:absolute;
		margin-left:685px;
}

.div13{
		margin-top:660px;
		font-size:15px;
		position:absolute;
		margin-left:840px;
}

.div14{
		background-color:;
		width:970px;
		height:70px;
		position:absolute;
		margin-top:100px;
		margin-left:15px;
}

.div15{
		margin-top:660px;
		font-size:15px;
		position:absolute;
		margin-left:530px	
}

.div16{
		margin-top:660px;
		font-size:15px;
		position:absolute;
		margin-left:3px	
}
.comp{
	
		!width:420px;
		!height:535px;
		padding:3px;
		margin-left:6px;
		background:rgba(20,20,20,.1);
}

.adcom{
	
		font-size:30px;
		margin-top:10px;
	
}
		


.footer{
		background-color:#b2beb5;
		position:absolute;
		margin-top:1180px;
		width:100%;
		height:110px;
		padding:3px;
		
}

.f1{
		background-color:	;
		position:absolute;
		
}

.f2{
		position:absolute;
		margin-left:1650px;
		margin-top:60px;
}

.h{
		position:absolute;
		width:100%;
}

.header1{
		height:50px;
		background: #505050;
		width:100%;
		position:absolute;
		
	}
	
.header2{
		height:110px;
		background:#b2beb5;
		padding-top:5px;
		position:absolute;
		width:100%;
		margin-top:50px;
}

	
.logo1{
		margin-top:6px;
			
}


.btn{
		height :"50px";
		width : "100px";
}

.menu{
		width:100%;
		background:#142b47;
		overflow:auto;
		position:absolute;
		margin-top:165px
		
}

.menu ul{
		margin:0;
		padding:0;
		list-style:none;
		line-height:50px;
}

.menu li{
		float:left;
}

.menu ul li a{
		background:#142b47;
		text-decoration:none;
		width:160px;
		display:block;
		text-align:center;
		color:#f2f2f2;
		font-size:20px;
		font-family:sans-serif;
		letter-spacing:0.5px;
}

.menu li a:hover{
		color:#fff;
		opacity:0.5;
		font-size:18px;
}

.search-form{
		margin-top:10px;
		float:right;
		margin-right:300px;
}

input[type=text]{
		padding: 7px;
		border:none;
		font-size:16px;
		font-family:sans-serif;

}

.button{
		float:right;
		background-color:orange;
		color:white;
		border-radius:0 8px 8px 0;
		cursor:pointer;
		position:relative;
		padding:7px;
		font-family:sans-serif;
		border:none;
		font-size:16px;
}


.button1{
		float:right;
		margin-right:-335px;
		margin-top:4px;
		border-radius:50%;

}
		
.button2{
		float:right;
		margin-right:-500px;
		margin-top:9px;
		background-color:orange;
		color:white;
		border-radius:5px 5px 5px 5px;

}

.button3{
		color:white;
		border-radius:0px 0px 0px 0px;
		background-color:Black;
		width:120px;
		height:50px;
		margin-top:10px;
		float:right;
		font-size:20px;
		margin-right:15px;
}

.button4{
		float:right;
		color:white;
		border-radius:0 0px 0px 0px;
		background-color:Black;
		width:380px;
		height:50px;
		margin-top:0px;
		font-size:20px;
}

.button5{
		position:absolute;
		margin: 10px 500px 0 1710px;
		width:100px;
		height:25px;
		background:rgba(0,0,0,.8);
		border-radius:5px;
		color:white;
}


.img1{
	
		margin-top:-11px;

}

.img2{
	
		margin-top:6px;
		margin-right:115px
}

.img3{
	
		margin-top:92px;
		margin-left:5px;
}

.img4{
	
		margin-top:93px;
		margin-left:225px;
}

.img5{
	
		margin-top:;
		margin-right:;
		
}

.img6{
	
		margin-top:;
		margin-right:;
		
}

.img7{
	
		margin-top:;
		margin-right:;
		
}

.img8{
	
		margin-top:;
		margin-right:;
		
}


.textbox1{
		margin-top:20px;
		margin-left:5px;
		width:200px;
		height:25px;
		line-height:25px;
}

.textbox2{

		margin-bottom:100px;
		margin-left:5px;
		width:200px;
		line-height:25px;
		list-style:none;
		line-height:40px;
}
		
.textbox3{

		margin-bottom:100px;
		margin-right:600px;
		margin-top:20px;
		width:1000px;
		line-height:25px;
		list-style:none;
		line-height:40px;
		background:rgba(255,255,255,.1);
		position:absolute;
		
		
}

	
.p1{
		font-size:40px;
		font-family:sans-serif;
		margin-top:0px;
}

.p2{
		font-size:40px;
		font-family:sans-serif;
		margin-top:0px;
}

.p3{
		font-size:15px;
		margin-top:-1px;
		margin-left:5px;
}

.p4{
		font-size:15px;
		margin-top:95px;
		margin-left:30px;
}

.p5{
		font-size:15px;
		margin-top:95px;
		margin-left:250px;
		
}

.p6{
		margin-left:50%;
		margin-top:70px;
}


.table1{
		float:left;
		position:absolute;
		margin-top:340px;
}



.tx{
		width:375px;
		height:50px;
		font-size:24px;
		background:rgba(255,255,255,.1);
}

.cbox{
		margin-top:50px;
}

.ad{
		background:rgba(255,255,255,.1);
		position:absolute;
		width:100%;
		height:180px;
		margin-top:980px;
		padding:3px;
		border:1px black groove;
}

.txtad{
	
		background:rgba(355,355,355,.1);
		width:100%;
		height:180px;
		margin-top:1000px;
		margin-top:0px;
		position:absolute;
	
}

		

	

