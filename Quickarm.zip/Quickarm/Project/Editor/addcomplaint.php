<?php
	include_once 'config.php';
	session_start();
?>
	
<?php


	$recordId =$_SESSION['Login'];
	$sql = "SELECT editor_id FROM editor where e_mail ='$recordId'";
	$result = $conn -> query($sql);
				if($result->num_rows > 0){
			//ouput data of each row
			
				while ($row = $result->fetch_assoc()){
				
					$userid=$row["editor_id"];
					
				}}


$comp = $_POST["complaints"];


$sql = "insert into complaints (comp_id,complaints,editor_id) values ('','$comp ','$userid')";

if(mysqli_query($conn,$sql)){
	
	header("Location:Editor_page.php");
	
}

else {

	echo "<script> alert( 'Submission Failed')</script>";
	

}

mysqli_close($conn);  

?>