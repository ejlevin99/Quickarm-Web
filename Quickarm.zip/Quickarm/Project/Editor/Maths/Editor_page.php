<?php
	include_once 'config.php';	
?>




<!DOCTYPE html>
<html>
<head>
	<meta name"viewport" content="width=device-width,initial-scale=1">
	<link rel = "stylesheet" type = "text/css" href = "Editor_page_css.css">
	<script src="Editor_js.js"></script>
	

</head>

<body background = "../../../LOGO/map.gif">

<div class="h">
<header class="header1">

	<center>
		<h2 class ="logo1">Online Discussion Forum</h2>
	</center>

</header>

<header class ="header2">

	<img src="../../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>

	<center>
		<img src = "../../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img2" ></img>
	</center>

</header>

<nav class="menu">
	<ul>
		<li><a href="../../Home/Home_Page_Editor.php">Home</a></li>
		<li><a href="../../Answer/answer_com.php">Answers</a></li>
		<li><a href="../../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../../Contact us/contact us.html">Contact us</a></li>
		
	</ul>
	
	
		<button class="button button1">
			<a href="../../Logg/Profile_Page_Editor.php"><img src="../../../LOGO/person1.png" width="35px" height="25px"></a>
		</button>
		<a href="../../Question/cpq.html"><button class="button button2">Add Questions</button></a>
		<button type="submit" class="buttonx " onclick="window.location.href='logout.php'" >Logout</button>

</nav>
</div>

<div class="table1">
<fieldset class="textbox1">Select your Category</fieldset>

<fieldset Class="textbox2">	
	<li><a class="L1" onclick="Subjectfunction('L1'),loadData('L1')" href="../Editor_page.php">Computer Programming</a></li>
	<li><a class="L2" onclick="Subjectfunction('L2'),loadData('L2')" href="#" >Mathematics</a></li>
	<li><a class="L3" onclick="Subjectfunction('L3'),loadData('L3')" href="../Bio/Editor_page.php">Biology</a></li>
	<li><a class="L4" onclick="Subjectfunction('L4'),loadData('L4')" >Physics</a></li>
	<li><a class="L5" onclick="Subjectfunction('L5'),loadData('L5')" >Chemistry</a></li>
	<li><a class="L6" onclick="Subjectfunction('L6'),loadData('L6')" >Economics</a></li>
	<li><a class="L7" onclick="Subjectfunction('L7'),loadData('L7')" >Languages</a></li>
	<li><a class="L8" onclick="Subjectfunction('L8'),loadData('L8')" >History</a></li>
	<li><a class="L9" onclick="Subjectfunction('L9'),loadData('L9')" >Geography</a></li>
	<li><a class="L10" onclick="Subjectfunction('L10'),loadData('L10')">Citizenship</a></li>
	<li><a class="L11" onclick="Subjectfunction('L11'),loadData('L11')">Aesthetic</a></li>
</fieldset>	
</div>


<div class="div1">
<form method="POST" action="">
<div class="div2">
<div class="div3"><p class="p1">Questions</p></div>
<div class="div4" id="cp12">Mathematics</div>
<div class="div5"><table class="q" style="width:100%"  border = "1px solid black" bgcolor = "white">
			<tr>
			<th>Q_id</th>
			<th>Questions</th>
			<th>Add answer</th>
			<th>Delete</th>
			
		</tr>

<?php
	
	include_once 'config.php';

			$sql = "SELECT * FROM qmaths";
			$result = $conn -> query($sql);
			if($result->num_rows > 0){
			//ouput data of each row
			
				while ($row = $result->fetch_assoc()){
				
					$id=$row['q_id'];
					
					echo "<tr><td>".$row["q_id"]."</td>";
					echo "<td>".$row["question"]."</td>";
					echo "<td><center><button type='submit' ><a href ='insertans_com.php?Id=$id'>Add answer</a></button></center></td>";
					echo "<td><center><button type='submit'  ><a href ='delete_q.php?Id=$id'>Delete</a></button></center></td></tr>";
					
				}
				}
				else {
				
					echo "0 result";
				}
				echo "</table>";
				$conn->close();
				
?></div>
</div>
</form>
</div>


<div class="div8">
<form method="POST" action="addcomplaint.php">			
<div class="div9"><p class="adcom" align="center">Add Complaints</p></div>
<div class="div10"><textarea rows="35" cols="59" name="complaints" class="comp"></textarea></div>
<div class="div11"><input type="submit" name="send" value="Submit" class="snd"></div>



</form>

</div>



<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="../About Us/feedaback.html"><input type="button" class="button5" value="Feed Back"></a>
<div class="f1"><img src="../../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>
<div class="f2"><a href="https://www.facebook.com"><img src="../../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px "></a>
				<a href="https://twitter.com/login?lang=en"><img src="../../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px"></a>
				<a href= "https://lk.linkedin.com"><img src="../../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px"></a>
				<a href="https://www.instagram.com"><img src="../../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px"></a>
</div>				
</footer>
</div>



</body>
</html>