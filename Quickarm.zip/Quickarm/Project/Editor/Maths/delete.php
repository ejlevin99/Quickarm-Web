<?php
	include_once 'config.php';
?>

<?php
	
	$recordId = $_GET['Id'];
	$sql = "DELETE  FROM answer_maths where a_id = $recordId";
	$result = $conn -> query($sql);
	
			
if(mysqli_query($conn,$sql)){
	
	header("Location:Editor_page.php");
	
}

else {

	echo "<script> alert( 'Submission Failed')</script>";

}

mysqli_close($conn); 

?>