<?php
	include_once 'config.php';
	
	
	
	$qid = $_POST["qId"];
	$answer_cp = $_POST["answers"];
	
	
	
	$sql = "insert into answer_maths(a_id,answer,q_id) values('','$answer_cp','$qid')";
	
	if (mysqli_query($conn,$sql))
	{
		header("Location:Editor_page.php");
	}
	else
	{
		echo "Error!";
		
	}
	
	//Close connection
	mysqli_close($conn);
?>