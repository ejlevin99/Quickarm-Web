
	
	
	
		<?php
		
		include_once 'config_feed.php';
		
				$questionBio = $_POST["t_1"];
	
	
				$sql = "insert into  qbio(q_id,question)values('','$questionBio')";
	
				if (mysqli_query($conn,$sql))
				{
					header("Location:Addq.html");
				}
				else
				{
					echo "Error!";
		
				}
	
				//Close connection
				mysqli_close($conn);
				
				?>
				
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
