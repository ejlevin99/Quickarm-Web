
	
	
	
	
		<?php
		
				include_once 'config_feed.php';
			
				$questionMath = $_POST["t_1"];
	
	
				$sql= "insert into qmaths(q_id,question)values('','$questionMath')";
	
				if (mysqli_query($conn,$sql))
				{
					header("Location:Addq.html");
				}
				else
				{
					echo "Error!";
		
				}
	
				//Close connection
				mysqli_close($conn);
		?>
			
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
