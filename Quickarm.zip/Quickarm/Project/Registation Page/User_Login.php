<?php

	include_once 'confi.php';


	$fname = $_POST["fname"];
	$lname = $_POST["lname"];
	$email =  $_POST["em"];
	$password =  $_POST["psw"];
	$birthday =  $_POST["bday"];
	
	$sql = "insert into user(user_id,f_name,l_name,e_mail,password,b_day)values('','$fname','$lname','$email','$password','$birthday')";

	if (mysqli_query($conn,$sql))
	{
		$_SESSION['message']='Registation is successfully!,Added your data to the database!';
		header("Location:../Home/Home_Page.php");
	}
	else
	{
		$_SESSION['message']='User could not be added to the database!';
		
	} 
	
	//Close connection
	mysqli_close($conn);

?>