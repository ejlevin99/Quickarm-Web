<?php
	include_once 'config.php';
	
?>
	
<?php


					$userid=$_POST["ID"];
					$fname = $_POST["fname"];
					$lname= $_POST["lname"];
					$email= $_POST["email"];
					$dob= $_POST["DOB"];
					$pword= $_POST["password"];
					
					


$sql = "UPDATE editor SET f_name = '$fname',l_name = '$lname',e_mail = '$email',b_day ='$dob' ,password = '$pword' WHERE editor_id = '$userid'";

if(mysqli_query($conn,$sql)){
	
	header("Location:Profile_Page_Editor.php");
	
}

else {
	
	echo "<script> alert( 'Submission Failed')</script>";


	
	

}

mysqli_close($conn);  

?>