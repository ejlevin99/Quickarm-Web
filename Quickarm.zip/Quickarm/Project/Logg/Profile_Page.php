<?php
	include_once 'config.php';
	session_start();
?>


<?php
	include_once 'config.php';
	
	$recordId =$_SESSION['Login'];
	echo $recordId;
	$sql = "SELECT * FROM user where e_mail ='$recordId'";
	$result = $conn -> query($sql);
	
			
			if($result->num_rows > 0){
			//ouput data of each row
			
				while ($row = $result->fetch_assoc()){
				
					$userid=$row["user_id"];
					echo $userid;
					$fname = $row["f_name"];
					$lname= $row["l_name"];
					$email= $row["e_mail"];
					$dob=$row["b_day"];
					$pword= $row["password"];
					
				}}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel = "stylesheet" type = "text/css" href = "Profile_page_css.css">
	<script src="Profile_page_js.js"></script>

</head>

<body background = "../../LOGO/map.gif">

<div class="h">
<header class="header1">

	<center>
		<h2 class ="logo1">Online Discussion Forum</h2>
	</center>

</header>

<header class ="header2">

	<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>

	<center>
		<img src = "../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img2" ></img>
	</center>

</header>

<nav class="menu">
	<ul>
		<li><a href="../Home/Home_Page.php">Home</a></li>
		<li><a href="../Answer/answer_com.php">Answers</a></li>
		<li><a href="../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../contact us/contact us.html">Contact us</a></li>
		
	</ul>
	
	

		<button class="button button1">
			<a href="#"><img src="../../LOGO/person1.png" width="35px" height="25px"></a>
		</button>
		<a href="../Question/cpq.html"><button class="button button2">Add Questions</button></a>
		<button type="submit" class="buttonx " onclick="window.location.href='logout.php'" >Logout</button>		

</nav>
</div>

<div class="p1">
	<p>Your Profile</p>
</div>

<fieldset class="div1" >
<legend align="center"><img class="logi" id="logimg" style="border-radius:50%; border:1px black groove" src="../../LOGO/person1.png" onclick="logg_img()"></legend>
<form method = "post" action = "">
<input type= "hidden" name = "ID" value = <?php echo $userid ?> />
<p>First-Name</p>
<div class="div2"><input type="text" style="background:rgba(100,100,100,.1)" name="fname" value=<?php echo $fname ?> id="lg1" disabled></div><br/><br/>
<p>Last-Name</p>
<div class="div3"><input type="text" style="background:rgba(100,100,100,.1);border:none; height:20px ;"name = "lname" value=<?php echo $lname ?> id="lg2" disabled></div><br/><br/>
<p>E-Mail</p>
<div class="div4"><input type="email" style="background:rgba(100,100,100,.1) ;border:none; height:30px" name="email" value=<?php echo $email ?> id="lg3" disabled></div><br/><br/>
<p>Date of birth</p>
<div class="div5"><input type="date" name="DOB" value=<?php echo $dob ?> style="background:rgba(100,100,100,.1) ;border:none;height:30px" ></div><br/><br/>
<p>Reset-Password</p>
<div class="div6"><input type="password" style="background:rgba(100,100,100,.1); border:none; height:30px" name="password" value=<?php echo $pword ?> id="lg4" disabled></div>
<div class="div7"><a href="Profile_Page_Update.php"><input type="button" name="edit" value="Edit" class="snd" id="snd1" onclick="logg_edit()"></a></div>
<div class="div8"><input type="button" name="edit" value="Save changes" class="snd" id="snd1" onclick="logg_save()"></div>

</form>

</fieldset>





<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="../About Us/feedaback.html"><input type="button" class="button5" value="Feed Back"></a>
<div class="f1"><img src="../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>
<div class="f2"><a href="https://www.facebook.com"><img src="../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px "></a>
				<a href="https://twitter.com/login?lang=en"><img src="../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px"></a>
				<a href= "https://lk.linkedin.com"><img src="../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px"></a>
				<a href="https://www.instagram.com"><img src="../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px"></a>
</div>				
</footer>
</div>

</body>
</html>