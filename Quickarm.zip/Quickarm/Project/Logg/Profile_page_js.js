function logg_edit(){
			
			document.getElementById("lg1").disabled = false;
			document.getElementById("lg2").disabled = false;
			document.getElementById("lg3").disabled = false;
			document.getElementById("lg4").disabled = false;
			document.getElementById("lg5").disabled = false;
			
}

function logg_save(){

			document.getElementById("lg1").disabled = true;
			document.getElementById("lg2").disabled = true;
			document.getElementById("lg3").disabled = true;
			document.getElementById("lg4").disabled = true;
			document.getElementById("lg5").disabled = true;
}

function logg_img(){
			
			confirm("Do you want to edit ?");
			
}			
	
			
function Match(){

			var a = document.getElementById("em").value;
			var b = document.getElementById("pw").value;
			
			if(a=="editor@quickarm.com" && b=="editor")
			{
				alert("Matched");
			}
			else
			{
				alert("Mismatched");
				return false;
			}
			
}

function check(){

			if(document.getElementById("cbox").checked)
			{
				document.getElementById("button3").disabled = false;
			}
			
			else
			{
				document.getElementById("button3").disabled = true;
			}
}

function Subjectfunction(x){
			
			if(x=="L1")
			{
				alert("Computer Programming");
			}	
				
				else if(x=="L2")
					{
						alert("Mathematics");
					}	
					
					else if(x=="L3")
					{
						alert("Biolagy");
					}	
					
						else if(x=="L4")
					{
						alert("Physics");
					}

					
						else if(x=="L5")
					{
						alert("Chemistry");
					}
					
					
						else if(x=="L6")
					{
						alert("Economics");
					}
					
					
						else if(x=="L7")
					{
						alert("Languages");
					}
					
						else if(x=="L8")
					{
						alert("History");
					}
					
						else if(x=="L9")
					{
						alert("Geography");
					}
					
						else if(x=="L10")
					{
						alert("Citizenship");
					}
					
						else if(x=="L11")
					{
						alert("Aesthetic");
					}
					
					
					
					
					
						
					
			
}