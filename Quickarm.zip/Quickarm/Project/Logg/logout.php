<?php


session_destroy();

header("Location:../Home/Home_page.php");
?>