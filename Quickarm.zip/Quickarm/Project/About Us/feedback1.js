function submitFeedback()
{


	if(confirm("Are you sure want to submit your feedback?") == true)
	{
		location.replace("thanksFeedback.html");

	}

	else
	{
		alert("Re-enter your feedback");
		location.replace("feedaback.html");	
	}
	
	
	

}

function activeSubmit()
{
	if (document.getElementById("chk4").checked)
	{
		document.getElementById("submit1").disabled=false;
	
	}

	else
{
	document.getElementById("submit1").disabled=true;
}

}




function displaySelected(y)
{
	if(y == "yes")
	
	{
		document.getElementById('yes').style.backgroundColor='#4f465c';
	}

	else 

			if(y == "partial")
	
		document.getElementById('partial').style.backgroundColor='#4f465c';
	

		else if(y == "no")
	
		document.getElementById('no').style.backgroundColor='#4f465c';
	

	


}

function loadAbout(data)
{

	if(data == "vision")
	{
		document.getElementById('visionpara1').style.visibility='visible';
		document.getElementById('objectivespara1').style.visibility='hidden';
		document.getElementById('misionpara1').style.visibility='hidden';
	}

	
	else if(data == "mision")
	{
		document.getElementById('misionpara1').style.visibility='visible';
document.getElementById('visionpara1').style.visibility='hidden';
	document.getElementById('objectivespara1').style.visibility='hidden';
	}

	
	else if(data == "objectives")
	{
		document.getElementById('objectivespara1').style.visibility='visible';
		document.getElementById('visionpara1').style.visibility='hidden';
		document.getElementById('misionpara1').style.visibility='hidden';
	}
		

}

function contactUs1()
{

	if(confirm("Will load the Contact Us Page") == true)
	{
		location.replace("aboutUs1.html");

	}

	else
	{
		
		location.replace("thanksFeedback.html");	
	}

}

function changecolor()
{
	
		if (document.getElementById("c1").checked)
	{
		document.getElementById("feedRow").style.backgroundColor='#4f465c';
	
	}
}