<?php
	include_once 'config_feed.php';
	
	
	
	
	$firstName = $_POST["fname"];
	$lastName = $_POST["lname"];
	$email1 =  $_POST["mail"];
	$goal =  $_POST["yeah"];
	
	$checkAnswer =  $_POST["checkAns"];
	$checkQuestion =  $_POST["checkQue"];
	$checkSearch =$_POST["search"];
	$reasonVisit = $_POST["reason"];
	$sugeest =  $_POST["suggestions"];
	
	$sql = "insert into feedback(feedback_id,f_name,l_name,email,achieve_goal,cans,cque,csearch,reason_not_achieve,suggestions)values('','$firstName','$lastName','$email1','$goal','$checkAnswer','$checkQuestion','$checkSearch','$reasonVisit','$sugeest')";
	
	if (mysqli_query($conn,$sql))
	{
		header("Location:thanksfeedback.html");
	}
	else
	{
		echo "Error!";
		
	}
	
	//Close connection
	mysqli_close($conn);
?>