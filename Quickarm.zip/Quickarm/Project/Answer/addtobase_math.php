<?php
	include_once 'config_feed.php';
	
	
	
	$qidmaths = $_POST["qmathId"];
	$answer_maths = $_POST["answers_maths"];
	
	
	
	$sql = "insert into answer_maths(a_id,q_id,answer)values('','$qidmaths','$answer_maths')";
	
	if (mysqli_query($conn,$sql))
	{
		header("Location:answer_math.php");
	}
	else
	{
		echo "Error!";
		
	}
	
	//Close connection
	mysqli_close($conn);
?>