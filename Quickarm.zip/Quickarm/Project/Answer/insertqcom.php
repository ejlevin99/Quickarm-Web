
	
	
	
		<?php
		
		include_once 'config_feed.php';
		
				$questionComputer = $_POST["t_1"];
	
	
				$sql = "insert into qcom(q_id,question)values('','$questionComputer')";
	
				if (mysqli_query($conn,$sql))
				{
					header("Location:Addq.html");
				}
				else
				{
					echo "Error!";
		
				}
	
				//Close connection
				mysqli_close($conn);
				
				?>
				
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
