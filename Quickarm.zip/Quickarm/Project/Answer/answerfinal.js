function successmsg()
{
	confirm("Are you sure you want to submit?");
}

function loadData(x)
{
	if(x == "L1")
	{
		document.getElementById("cp12").innerHTML = "Computer Programming";
		document.getElementById("s").innerHTML = "Computer Programming Questions";
	}
	
	else if(x == "L2")
	{
		document.getElementById("cp12").innerHTML = "Mathematics";
		document.getElementById("s").innerHTML = "Mathematics Questions";
		
	}

	else if(x == "L3")
	{
		document.getElementById("cp12").innerHTML = "Biology";
		document.getElementById("s").innerHTML = "Biology Questions";
	}

	else if(x == "L4")
	{
		document.getElementById("cp12").innerHTML = "Physics";
		document.getElementById("s").innerHTML = "Physics Questions";
	}

	else if(x == "L5")
	{
		document.getElementById("cp12").innerHTML = "Chemistry";
		document.getElementById("s").innerHTML = "Chemistry Questions";
	}

	else if(x == "L6")
	{
		document.getElementById("cp12").innerHTML = "Economics";
		document.getElementById("s").innerHTML = "Economics Questions";
	}

	else if(x == "L7")
	{
		document.getElementById("cp12").innerHTML = "Languages";
		document.getElementById("s").innerHTML = "Languages Questions";
	}

	else if(x == "L8")
	{
		document.getElementById("cp12").innerHTML = "History";
		document.getElementById("s").innerHTML = "History Questions";
	}

	else if(x == "L9")
	{
		document.getElementById("cp12").innerHTML = "Geography";
		document.getElementById("s").innerHTML = "Geography Questions";
	}

	else if(x == "L10")
	{
		document.getElementById("cp12").innerHTML = "Citizenship";
		document.getElementById("s").innerHTML = "Citizenship Questions";
	}

	else if(x == "L11")
	{
		document.getElementById("cp12").innerHTML = "Aesthetic";
		document.getElementById("s").innerHTML = "Aesthetic Questions";
	}	
}




