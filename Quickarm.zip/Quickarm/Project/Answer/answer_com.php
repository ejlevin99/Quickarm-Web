<?php
	include_once 'config_feed.php';
	
	?>


<!DOCTYPE html>
<html>
<head>
	<link rel = "stylesheet" type = "text/css" href = "Answer_final_1_css.css">
	<script src="answerfinal.js"></script>
	
	
</head>

<body background = "../../LOGO/map.gif">

<div class="h">
<header class="header1">

	<center>
		<h2 class ="logo1">Online Discussion Forum</h2>
	</center>

</header>

<header class ="header2">

	<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>

	<center>
		<img src = "../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img2" ></img>
	</center>
 
</header>

<nav class="menu">
	<ul>
		<li><a href="../Home/Home_page.php">Home</a></li>
		<li><a href="#">Answers</a></li>
		<li><a href="../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../Contact us/contact us.html">Contact us</a></li>
		
	</ul>
	
	

	
		
		<button class="button button1">
			<a href="../Logg/Profile_Page.html"><img src="../../LOGO/person1.png" width="35px" height="25px"></a>
		</button>
		<a href="../Question/cpq.html"><button class="button button2">Add Questions</button></a>

</nav>
</div>





<div class="table1">
<fieldset class="textbox1">Select your Category</fieldset>

<fieldset Class="textbox2">	
	<li><a class="L1" onclick="loadData('L1')" href="#">Computer Programming</a></li>
	<li><a class="L2" onclick="loadData('L2')" href="answer_math.php">Mathematics</a></li>
	<li><a class="L3" onclick="loadData('L3')" href="answer_bio.php">Biology</a></li>
	<li><a class="L4" onclick="loadData('L4')" href="#">Physics</a></li>
	<li><a class="L5" onclick="loadData('L5')" href="#">Chemistry</a></li>
	<li><a class="L6" onclick="loadData('L6')" href="#">Economics</a></li>
	<li><a class="L7" onclick="loadData('L7')" href="#">Languages</a></li>
	<li><a class="L8" onclick="loadData('L8')" href="#">History</a></li>
	<li><a class="L9" onclick="loadData('L9')" href="#">Geography</a></li>
	<li><a class="L10" onclick="LoadData('L10')" href="#">Citizenship</a></li>
	<li><a class="L11" onclick="LoadData('L11')" href="#">Aesthetic</a></li>
</fieldset>	
</div>


<div class="name"><h2 style="font-size:50px">Answer Page</h2></div>
<div class="div1">

<form method="POST" action="insert_answer.php">
<div class="div2">
<div class="div3"><p class="p1">Questions</p></div>
<div class="div4" id="cp12">Computer Programming</div>
<div class="div5">

<table border="1" width="100%">
	<tr>
	<th>Question ID</th>
	<th>Question</th>
	<th>Click on following button to add an answer</th>
	
	
	</tr>
	
	<?php
		$sql = "select * from question";
		$result = $conn->query($sql);
		
		if($result->num_rows > 0)
		{
			//output the data of each row
			while($row = $result->fetch_assoc())
			{
				$id = $row["q_id"];
				
				echo"<tr><td>".$row["q_id"]."</td>";
				echo"<td>".$row["question"]."</td>";
				echo"<td><center><button type='submit'><a href='insertans_com.php?Id=$id'>Add an Answer</a></button></center></td></tr>";
			}
		}
		else
		{
			echo "0 results";
		}
		
		echo "</table>";
		
		$conn->close();
		
	
	
	?>
	









</div>

</form>
</div>
</div>






<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="../About Us/feedaback.html"><input type="button" class="button5" value="Feed Back"></a>
<div class="f1"><img src="../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>
<div class="f2"><img src="../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px ">
				<img src="../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px">
				<img src="../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px">
				<img src="../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px">
</div>				
</footer>
</div>

</body>
</html>