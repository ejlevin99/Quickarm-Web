<?php
	include_once 'config_feed.php';
	
	
	
	$qidbio = $_POST["qbioId"];
	$answer_bio = $_POST["answers_bio"];
	
	
	
	$sql = "insert into answer_bio(a_id,q_id,answer)values('','$qidbio','$answer_bio')";
	
	if (mysqli_query($conn,$sql))
	{
		header("Location:answer_bio.php");
	}
	else
	{
		echo "Error!";
		
	}
	
	//Close connection
	mysqli_close($conn);
?>