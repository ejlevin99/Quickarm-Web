<?php
	include_once 'config_feed.php';
	
	
	
	$qid = $_POST["qcpId"];
	$answer_cp = $_POST["answers"];
	
	
	
	$sql = "insert into answer_com(a_id,q_id,answer)values('','$qid','$answer_cp')";
	
	if (mysqli_query($conn,$sql))
	{
		header("Location:answer_com.php");
	}
	else
	{
		echo "Error!";
		
	}
	
	//Close connection
	mysqli_close($conn);
?>