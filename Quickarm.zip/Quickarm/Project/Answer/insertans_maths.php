<!DOCTYPE html>
<html>
<head>
	<link rel = "stylesheet" type = "text/css" href = "Answer_final_1_css.css">
	<script src="answerfinal.js"></script>
	<?php
	include_once 'config_feed.php';
	?>

</head>

<body background = "../../LOGO/map.gif">

<div class="h">
<header class="header1">

	<center>
		<h2 class ="logo1">Online Discussion Forum</h2>
	</center>

</header>

<header class ="header2">

	<img src="../../LOGO/LOGO.png" align="left" width="127px" height="127px" class="img1" ></img>

	<center>
		<img src = "../../LOGO/quickarm.jpg" width="288px" height="127px"  alt="This is a sliit image" class="img2" ></img>
	</center>
 
</header>

<nav class="menu">
	<ul>
		<li><a href="../Home/Home_page.html">Home</a></li>
		<li><a href="#">Answers</a></li>
		<li><a href="../About Us/aboutUsjs123.html">About us</a></li>
		<li><a href="../contact us/contact us.html">Contact us</a></li>
		
	</ul>
	
	

	
		<button class="button button1">
			<a href="../Logg/Profile_Page.html"><img src="../../LOGO/person1.png" width="35px" height="25px"></a>
		</button>
		<a href="../Add Question/About_Question_.html"><button class="button button2">Add Questions</button></a>

</nav>
</div>


<br><br><br><br><br><br><br><br><br><br>
<center><h2>Add your Answer</h2></center>

<?php

	$recordId=$_GET['Id'];
	
	$sql = "select * from qmaths where q_id=$recordId";
	
	$result = $conn->query($sql);
		
		if($result->num_rows > 0)
		{
			//output the data of each row
			while($row = $result->fetch_assoc())
			{
				
				
					
					$questionmaths = $row["question"];
					
			}
		}
?>





<form method="POST" action="addtobase_math.php">





Question :

<input type="hidden"   name="qmathId" value=<?php echo $recordId?>/>
<textarea rows="3" cols="50"><?php echo $questionmaths?></textarea>

<br><br>



Answers :

<table border="1" width="100%">
	<tr>
	<th>Answer</th>
	</tr>
	
	<?php
		$sql = "select * from answer_maths where q_id=$recordId";
		$result = $conn->query($sql);
		
		if($result->num_rows > 0)
		{
			//output the data of each row
			while($row = $result->fetch_assoc())
			{
				
				echo"<tr><td>".$row["answer"]."</td></tr>";
				
			}
		}
		else
		{
			echo "0 results";
		}
		
		echo "</table>";
		
		$conn->close();
		
	
	
	?>
	
		
	
	
	</table>






<br><br>


Add your Answer here:

<br><br>

<input type="text" name="answers_maths" class="q">

<br><br>

<input type="submit" value="POST" name="btn"/>


</form>
</html>



















<div class="footer">
<footer>
<div class="f1"><p class="p3" >Quickarm &copy;</p></div>
<div class="f1"><p class="p4" >https://www.quickarm.com</p></div>
<div class="f1"><p class="p5" >quickarm@gmail.com</p></div>
<a href="../About Us/feedaback.html"><input type="button" class="button5" value="Feed Back"></a>
<div class="f1"><img src="../../LOGO/attached.png" width="17px" height="17px" class="img3" align="left"></div>
<div class="f1"><img src="../../LOGO/email.png" width="20px" height="20px" class="img4" align="left"></div>
<div class="f2"><img src="../../LOGO/facebook.png" width="40px" height="40px" class="img5" style="padding:5px ">
				<img src="../../LOGO/twitter.png" width="40px" height="40px" class="img6" style="padding:5px">
				<img src="../../LOGO/linkedin.png" width="40px" height="40px" class="img7" style="padding:5px">
				<img src="../../LOGO/instagram.png" width="40px" height="40px" class="img8" style="padding:5px">
</div>				
</footer>
</div>

</body>
</html>